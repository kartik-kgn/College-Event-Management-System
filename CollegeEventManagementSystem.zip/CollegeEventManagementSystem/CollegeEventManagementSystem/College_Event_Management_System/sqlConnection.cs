﻿namespace College_Event_Management_System
{
    internal class sqlConnection
    {
        private string v;

        public sqlConnection(string v)
        {
            this.v = v;
        }
    }
}