﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace College_Event_Management_System
{
    public partial class EventReport : Form
    {
        public EventReport()
        {
            InitializeComponent();
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void EventList_Load(object sender, EventArgs e)
        {
            loadData();
        }
        public void loadData()
        {
            SqlConnection conn = new SqlConnection("Data Source=(local);Initial Catalog=EventList;Integrated Security=True");
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
            }

            SqlCommand cmd1 = new SqlCommand("select * from EventTable", conn);

            SqlDataAdapter da = new SqlDataAdapter();

            DataTable dt = new DataTable();

            da.SelectCommand = cmd1;

            dt.Clear();
            da.Fill(dt);

            Eventtable.DataSource = dt;

            Eventtable.RowHeadersVisible = false;
        }
        

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection("Data Source=(local);Initial Catalog=EventList;Integrated Security=True"))
                {
                    conn.Open();

                    if (Eventtable.SelectedRows.Count > 0)
                    {
                        string eventnameToDelete = Eventtable.SelectedRows[0].Cells["eventname"].Value.ToString();

                        using (SqlCommand cmd4 = new SqlCommand("DELETE FROM EventTable WHERE eventname = @eventname", conn))
                        {
                            cmd4.Parameters.AddWithValue("@eventname", eventnameToDelete);
                            cmd4.ExecuteNonQuery();

                            MessageBox.Show("Successfully Deleted");
                            loadData();
                        }

                    }
                    else
                    {
                        MessageBox.Show("Please select a row to delete.");
                    }
                }
            }

            catch (Exception ex)
            {

            }
        }

        private void display()
        {
            throw new NotImplementedException();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Do You want to Close this Window", "Confirmation Message", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
            if (result == System.Windows.Forms.DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are You Sure, You want to Close??", "Confirmation Message", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
            if (result == System.Windows.Forms.DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=(local);Initial Catalog=EventList;Integrated Security=True");
            con.Open();
            SqlCommand cmd4 = new SqlCommand("select * from EventTable where Year=@Year", con);
            cmd4.Parameters.AddWithValue("@Year", searchbox.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd4);
            DataTable dt2 = new DataTable();
            da.Fill(dt2);

            Eventtable.DataSource = dt2;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Refresh_Click(object sender, EventArgs e)
        {
            loadData();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection("Data Source=(local);Initial Catalog=EventList;Integrated Security=True"))
                {
                    conn.Open();

                    if (Eventtable.SelectedRows.Count > 0)
                    {
                        string eventnameToDelete = Eventtable.SelectedRows[0].Cells["eventname"].Value.ToString();

                        using (SqlCommand cmd4 = new SqlCommand("DELETE FROM EventTable WHERE eventname = @eventname", conn))
                        {
                            cmd4.Parameters.AddWithValue("@eventname", eventnameToDelete);
                            cmd4.ExecuteNonQuery();

                            MessageBox.Show("Successfully Deleted");
                            loadData();
                        }

                    }
                    else
                    {
                        MessageBox.Show("Please select a row to delete.");
                    }
                }
            }

            catch (Exception ex)
            {

            }
        }

        private void USERNAME_Click(object sender, EventArgs e)
        {

        }

        private void searchbox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
