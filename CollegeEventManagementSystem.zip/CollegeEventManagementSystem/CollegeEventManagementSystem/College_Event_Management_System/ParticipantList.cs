﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace College_Event_Management_System
{
    public partial class ParticipantList : Form
    {
        public ParticipantList()
        {
            InitializeComponent();
        }

        private void ParticipantList_Load(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=(local);Initial Catalog=EventList;Integrated Security=True");
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();

            }

            SqlCommand cmd2 = new SqlCommand("select * from ParticipantTable", conn);

            SqlDataAdapter da2 = new SqlDataAdapter();

            DataTable dt2 = new DataTable();

            da2.SelectCommand = cmd2;

            dt2.Clear();
            da2.Fill(dt2);

            ParticipantList1.DataSource = dt2;

            ParticipantList1.RowHeadersVisible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Do You want to Close this Window", "Confirmation Message", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
            if (result == System.Windows.Forms.DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=(local);Initial Catalog=EventList;Integrated Security=True");
            conn.Open();
            SqlCommand cmd4 = new SqlCommand("select * from ParticipantTable where ParticipatingEvent LIKE @ParticipatingEvent", conn);
            cmd4.Parameters.AddWithValue("@ParticipatingEvent", searchbox.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd4);
            DataTable dt = new DataTable();
            da.Fill(dt);

            ParticipantList1.DataSource = dt;
        }
        private void Search() {

            SqlConnection conn = new SqlConnection("Data Source=(local);Initial Catalog=EventList;Integrated Security=True");
            conn.Open();
            SqlCommand cmd4 = new SqlCommand("SELECT * from ParticipantTable where ParticipatingEvent LIKE @ParticipatingEvent", conn);
            cmd4.Parameters.AddWithValue("@ParticipatingEvent", searchbox.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd4);
            DataTable dt = new DataTable();
            da.Fill(dt);

            ParticipantList1.DataSource = dt;
        }

        private void searchbox_TextChanged(object sender, EventArgs e)
        {
            Search();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection("Data Source=(local);Initial Catalog=EventList;Integrated Security=True"))
                {
                    conn.Open();

                    if (ParticipantList1.SelectedRows.Count > 0)
                    {
                        string participantNameToDelete = ParticipantList1.SelectedRows[0].Cells["ParticipantName"].Value.ToString();
                        using (SqlCommand cmd4 = new SqlCommand("DELETE FROM ParticipantTable WHERE ParticipantName = @ParticipantName", conn))
                        {
                            cmd4.Parameters.AddWithValue("@ParticipantName", participantNameToDelete);
                            cmd4.ExecuteNonQuery();

                            MessageBox.Show("Successfully Deleted");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please select a row to delete.");
                    }
                    loadData();
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are You Sure, You want to Close??", "Confirmation Message", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
            if (result == System.Windows.Forms.DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=(local);Initial Catalog=EventList;Integrated Security=True");
            con.Open();
            SqlCommand cmd4 = new SqlCommand("select * from ParticipantTable where Year=@Year", con);
            cmd4.Parameters.AddWithValue("@Year", SearchBox2.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd4);
            DataTable dt2 = new DataTable();
            da.Fill(dt2);

            ParticipantList1.DataSource = dt2;
        }
        public void loadData()
        {
            SqlConnection conn = new SqlConnection("Data Source=(local);Initial Catalog=EventList;Integrated Security=True");
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();

            }

            SqlCommand cmd1 = new SqlCommand("select * from ParticipantTable", conn);

            SqlDataAdapter da = new SqlDataAdapter();

            DataTable dt = new DataTable();

            da.SelectCommand = cmd1;

            dt.Clear();
            da.Fill(dt);

            ParticipantList1.DataSource = dt;

            ParticipantList1.RowHeadersVisible = false;
        }
        private void ParticipantList1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Refresh_Click(object sender, EventArgs e)
        {
            loadData();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection("Data Source=(local);Initial Catalog=EventList;Integrated Security=True"))
                {
                    conn.Open();

                    if (ParticipantList1.SelectedRows.Count > 0)
                    {
                        string participantNameToDelete = ParticipantList1.SelectedRows[0].Cells["ParticipantName"].Value.ToString();

                        using (SqlCommand cmd4 = new SqlCommand("DELETE FROM ParticipantTable WHERE ParticipantName = @ParticipantName", conn))
                        {
                            cmd4.Parameters.AddWithValue("@ParticipantName", participantNameToDelete);
                            cmd4.ExecuteNonQuery();

                            MessageBox.Show("Successfully Deleted");
                        }

                    }
                    else
                    {
                        MessageBox.Show("Please select a row to delete.");
                    }
                    loadData();

                }
            }

            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }

        }
    }
}
