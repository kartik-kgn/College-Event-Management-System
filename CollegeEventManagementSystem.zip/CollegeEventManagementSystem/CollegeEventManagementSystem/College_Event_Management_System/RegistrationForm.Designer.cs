﻿namespace College_Event_Management_System
{
    partial class RegistrationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RegistrationForm));
            this.panel1 = new System.Windows.Forms.Panel();
            this.SaveBtn2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.S = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.SaveBtn = new System.Windows.Forms.Button();
            this.mailBox = new System.Windows.Forms.TextBox();
            this.c = new System.Windows.Forms.TextBox();
            this.passBox = new System.Windows.Forms.TextBox();
            this.userBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.SaveBtn2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.S);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.SaveBtn);
            this.panel1.Controls.Add(this.mailBox);
            this.panel1.Controls.Add(this.c);
            this.panel1.Controls.Add(this.passBox);
            this.panel1.Controls.Add(this.userBox);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(6, 10);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(982, 680);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // SaveBtn2
            // 
            this.SaveBtn2.BackColor = System.Drawing.Color.DarkGreen;
            this.SaveBtn2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SaveBtn2.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.SaveBtn2.ForeColor = System.Drawing.Color.White;
            this.SaveBtn2.Location = new System.Drawing.Point(250, 583);
            this.SaveBtn2.Name = "SaveBtn2";
            this.SaveBtn2.Size = new System.Drawing.Size(301, 45);
            this.SaveBtn2.TabIndex = 76;
            this.SaveBtn2.Text = "SAVE";
            this.SaveBtn2.UseVisualStyleBackColor = false;
            this.SaveBtn2.Click += new System.EventHandler(this.SaveBtn2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.SystemColors.Control;
            this.button1.Location = new System.Drawing.Point(664, 576);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(69, 57);
            this.button1.TabIndex = 75;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // S
            // 
            this.S.BackColor = System.Drawing.Color.Transparent;
            this.S.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("S.BackgroundImage")));
            this.S.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.S.Cursor = System.Windows.Forms.Cursors.Hand;
            this.S.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.S.ForeColor = System.Drawing.SystemColors.Control;
            this.S.Location = new System.Drawing.Point(930, 21);
            this.S.Name = "S";
            this.S.Size = new System.Drawing.Size(35, 34);
            this.S.TabIndex = 42;
            this.S.UseVisualStyleBackColor = false;
            this.S.Click += new System.EventHandler(this.button1_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Comic Sans MS", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.OrangeRed;
            this.label4.Location = new System.Drawing.Point(385, 41);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(217, 35);
            this.label4.TabIndex = 28;
            this.label4.Text = "Registration Page";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // SaveBtn
            // 
            this.SaveBtn.BackColor = System.Drawing.Color.DarkGreen;
            this.SaveBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SaveBtn.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.SaveBtn.ForeColor = System.Drawing.Color.White;
            this.SaveBtn.Location = new System.Drawing.Point(250, 584);
            this.SaveBtn.Name = "SaveBtn";
            this.SaveBtn.Size = new System.Drawing.Size(301, 45);
            this.SaveBtn.TabIndex = 27;
            this.SaveBtn.Text = "SAVE";
            this.SaveBtn.UseVisualStyleBackColor = false;
            this.SaveBtn.Click += new System.EventHandler(this.button4_Click);
            // 
            // mailBox
            // 
            this.mailBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mailBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Lower;
            this.mailBox.Font = new System.Drawing.Font("Times New Roman", 13F);
            this.mailBox.Location = new System.Drawing.Point(251, 478);
            this.mailBox.Multiline = true;
            this.mailBox.Name = "mailBox";
            this.mailBox.Size = new System.Drawing.Size(481, 45);
            this.mailBox.TabIndex = 24;
            this.mailBox.TextChanged += new System.EventHandler(this.mailBox_TextChanged);
            // 
            // c
            // 
            this.c.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.c.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.c.Font = new System.Drawing.Font("Times New Roman", 13F);
            this.c.Location = new System.Drawing.Point(252, 371);
            this.c.Multiline = true;
            this.c.Name = "c";
            this.c.Size = new System.Drawing.Size(481, 45);
            this.c.TabIndex = 23;
            this.c.TextChanged += new System.EventHandler(this.nameBox_TextChanged);
            // 
            // passBox
            // 
            this.passBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.passBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.passBox.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.passBox.Location = new System.Drawing.Point(252, 264);
            this.passBox.Multiline = true;
            this.passBox.Name = "passBox";
            this.passBox.PasswordChar = '*';
            this.passBox.Size = new System.Drawing.Size(481, 45);
            this.passBox.TabIndex = 22;
            this.passBox.TextChanged += new System.EventHandler(this.passBox_TextChanged);
            // 
            // userBox
            // 
            this.userBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.userBox.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userBox.Location = new System.Drawing.Point(251, 151);
            this.userBox.Multiline = true;
            this.userBox.Name = "userBox";
            this.userBox.Size = new System.Drawing.Size(481, 45);
            this.userBox.TabIndex = 21;
            this.userBox.TextChanged += new System.EventHandler(this.userBox_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI Semibold", 8F, System.Drawing.FontStyle.Bold);
            this.label5.Location = new System.Drawing.Point(248, 449);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(79, 21);
            this.label5.TabIndex = 20;
            this.label5.Text = "EMAIL-ID";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI Semibold", 8F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(249, 234);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(95, 21);
            this.label3.TabIndex = 19;
            this.label3.Text = "PASSWORD";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI Semibold", 8F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(249, 343);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 21);
            this.label2.TabIndex = 18;
            this.label2.Text = "NAME";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 8F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(248, 121);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 21);
            this.label1.TabIndex = 17;
            this.label1.Text = "USERNAME";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // RegistrationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(994, 683);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "RegistrationForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "RegistrationForm";
            this.Load += new System.EventHandler(this.RegistrationForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox mailBox;
        private System.Windows.Forms.TextBox c;
        private System.Windows.Forms.TextBox passBox;
        private System.Windows.Forms.TextBox userBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button S;
        private System.Windows.Forms.Button button1;
        public System.Windows.Forms.Button SaveBtn;
        public System.Windows.Forms.Button SaveBtn2;
    }
}