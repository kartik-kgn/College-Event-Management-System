﻿namespace College_Event_Management_System
{
    partial class MainFrmAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainFrmAdmin));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.aDDEVENTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eVENTREPORTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aDDPARTICIPANTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pARTICIPANTLISTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.privacybtn = new System.Windows.Forms.ToolStripMenuItem();
            this.rEGISTRATIONToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uSERDETAILToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eXITToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem9 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.AutoSize = false;
            this.menuStrip1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.Left;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem7,
            this.toolStripMenuItem6,
            this.aDDEVENTToolStripMenuItem,
            this.toolStripMenuItem1,
            this.eVENTREPORTToolStripMenuItem,
            this.toolStripMenuItem2,
            this.aDDPARTICIPANTToolStripMenuItem,
            this.toolStripMenuItem3,
            this.pARTICIPANTLISTToolStripMenuItem,
            this.toolStripMenuItem4,
            this.privacybtn,
            this.toolStripMenuItem5,
            this.toolStripMenuItem8,
            this.toolStripMenuItem9,
            this.eXITToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.menuStrip1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.menuStrip1.Size = new System.Drawing.Size(250, 509);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // aDDEVENTToolStripMenuItem
            // 
            this.aDDEVENTToolStripMenuItem.BackColor = System.Drawing.Color.WhiteSmoke;
            this.aDDEVENTToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold);
            this.aDDEVENTToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("aDDEVENTToolStripMenuItem.Image")));
            this.aDDEVENTToolStripMenuItem.Name = "aDDEVENTToolStripMenuItem";
            this.aDDEVENTToolStripMenuItem.Size = new System.Drawing.Size(243, 29);
            this.aDDEVENTToolStripMenuItem.Text = "ADD EVENT";
            this.aDDEVENTToolStripMenuItem.Click += new System.EventHandler(this.aDDEVENTToolStripMenuItem_Click);
            // 
            // eVENTREPORTToolStripMenuItem
            // 
            this.eVENTREPORTToolStripMenuItem.BackColor = System.Drawing.Color.WhiteSmoke;
            this.eVENTREPORTToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold);
            this.eVENTREPORTToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("eVENTREPORTToolStripMenuItem.Image")));
            this.eVENTREPORTToolStripMenuItem.Name = "eVENTREPORTToolStripMenuItem";
            this.eVENTREPORTToolStripMenuItem.Size = new System.Drawing.Size(243, 29);
            this.eVENTREPORTToolStripMenuItem.Text = "EVENT REPORT";
            this.eVENTREPORTToolStripMenuItem.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
            this.eVENTREPORTToolStripMenuItem.Click += new System.EventHandler(this.eVENTREPORTToolStripMenuItem_Click);
            // 
            // aDDPARTICIPANTToolStripMenuItem
            // 
            this.aDDPARTICIPANTToolStripMenuItem.BackColor = System.Drawing.Color.WhiteSmoke;
            this.aDDPARTICIPANTToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold);
            this.aDDPARTICIPANTToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("aDDPARTICIPANTToolStripMenuItem.Image")));
            this.aDDPARTICIPANTToolStripMenuItem.Name = "aDDPARTICIPANTToolStripMenuItem";
            this.aDDPARTICIPANTToolStripMenuItem.Size = new System.Drawing.Size(243, 29);
            this.aDDPARTICIPANTToolStripMenuItem.Text = "ADD PARTICIPANT";
            this.aDDPARTICIPANTToolStripMenuItem.Click += new System.EventHandler(this.aDDPARTICIPANTToolStripMenuItem_Click);
            // 
            // pARTICIPANTLISTToolStripMenuItem
            // 
            this.pARTICIPANTLISTToolStripMenuItem.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pARTICIPANTLISTToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold);
            this.pARTICIPANTLISTToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("pARTICIPANTLISTToolStripMenuItem.Image")));
            this.pARTICIPANTLISTToolStripMenuItem.Name = "pARTICIPANTLISTToolStripMenuItem";
            this.pARTICIPANTLISTToolStripMenuItem.Size = new System.Drawing.Size(243, 29);
            this.pARTICIPANTLISTToolStripMenuItem.Text = "PARTICIPANT LIST";
            this.pARTICIPANTLISTToolStripMenuItem.Click += new System.EventHandler(this.pARTICIPANTLISTToolStripMenuItem_Click);
            // 
            // privacybtn
            // 
            this.privacybtn.BackColor = System.Drawing.Color.WhiteSmoke;
            this.privacybtn.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rEGISTRATIONToolStripMenuItem,
            this.uSERDETAILToolStripMenuItem});
            this.privacybtn.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold);
            this.privacybtn.Image = ((System.Drawing.Image)(resources.GetObject("privacybtn.Image")));
            this.privacybtn.Name = "privacybtn";
            this.privacybtn.Size = new System.Drawing.Size(243, 29);
            this.privacybtn.Text = "PRIVACY";
            this.privacybtn.Click += new System.EventHandler(this.privacybtn_Click);
            // 
            // rEGISTRATIONToolStripMenuItem
            // 
            this.rEGISTRATIONToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("rEGISTRATIONToolStripMenuItem.Image")));
            this.rEGISTRATIONToolStripMenuItem.Name = "rEGISTRATIONToolStripMenuItem";
            this.rEGISTRATIONToolStripMenuItem.Size = new System.Drawing.Size(252, 30);
            this.rEGISTRATIONToolStripMenuItem.Text = "REGISTRATION";
            this.rEGISTRATIONToolStripMenuItem.Click += new System.EventHandler(this.rEGISTRATIONToolStripMenuItem_Click);
            // 
            // uSERDETAILToolStripMenuItem
            // 
            this.uSERDETAILToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("uSERDETAILToolStripMenuItem.Image")));
            this.uSERDETAILToolStripMenuItem.Name = "uSERDETAILToolStripMenuItem";
            this.uSERDETAILToolStripMenuItem.Size = new System.Drawing.Size(252, 30);
            this.uSERDETAILToolStripMenuItem.Text = "USER DETAIL";
            this.uSERDETAILToolStripMenuItem.Click += new System.EventHandler(this.uSERDETAILToolStripMenuItem_Click);
            // 
            // eXITToolStripMenuItem
            // 
            this.eXITToolStripMenuItem.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.eXITToolStripMenuItem.BackColor = System.Drawing.Color.WhiteSmoke;
            this.eXITToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold);
            this.eXITToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("eXITToolStripMenuItem.Image")));
            this.eXITToolStripMenuItem.Name = "eXITToolStripMenuItem";
            this.eXITToolStripMenuItem.Size = new System.Drawing.Size(243, 29);
            this.eXITToolStripMenuItem.Text = "EXIT";
            this.eXITToolStripMenuItem.Click += new System.EventHandler(this.eXITToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(243, 29);
            this.toolStripMenuItem1.Text = "   ";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(243, 29);
            this.toolStripMenuItem2.Text = "    ";
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(243, 29);
            this.toolStripMenuItem3.Text = "    ";
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(243, 29);
            this.toolStripMenuItem4.Text = "     ";
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(243, 29);
            this.toolStripMenuItem5.Text = "    ";
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(243, 29);
            this.toolStripMenuItem6.Text = "    ";
            this.toolStripMenuItem6.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay;
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.AutoSize = false;
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(174, 29);
            this.toolStripMenuItem7.Text = "    ";
            this.toolStripMenuItem7.Click += new System.EventHandler(this.toolStripMenuItem7_Click);
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(243, 29);
            this.toolStripMenuItem8.Text = "               ";
            // 
            // toolStripMenuItem9
            // 
            this.toolStripMenuItem9.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripMenuItem9.Name = "toolStripMenuItem9";
            this.toolStripMenuItem9.Size = new System.Drawing.Size(243, 29);
            this.toolStripMenuItem9.Text = "         ";
            // 
            // MainFrmAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1098, 509);
            this.Controls.Add(this.menuStrip1);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "MainFrmAdmin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.TransparencyKey = System.Drawing.Color.White;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.MainFrmAdmin_Load);
            this.Click += new System.EventHandler(this.MainFrmAdmin_Click);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.ToolStripMenuItem aDDEVENTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eVENTREPORTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aDDPARTICIPANTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pARTICIPANTLISTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rEGISTRATIONToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uSERDETAILToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eXITToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem privacybtn;
        public System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem9;
    }
}