﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace College_Event_Management_System
{
    public partial class AddParticipant : Form
    {
        public AddParticipant()
        {
            InitializeComponent();
            fillCombobox();
        }

        private void button2_Click(object sender, EventArgs e)
        {
           PName.Clear();
           PNum.Clear();
          
           PName.Focus();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void AddStudents_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            PName.Clear();
            
            PNum.Clear();
            PName.Focus();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are You Sure, You want to Close??", "Confirmation Message", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
            if (result == System.Windows.Forms.DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=(local);Initial Catalog=EventList;Integrated Security=True");
            conn.Open();
            SqlCommand cmd4 = new SqlCommand("insert into ParticipantTable1 values(@ParticipantName, @Class, @ParticipantingEvent, @MobileNumber, @Year)", conn);

            cmd4.Parameters.AddWithValue("@ParticipantName", PName.Text);
            cmd4.Parameters.AddWithValue("@Class", PClass.Text);
            cmd4.Parameters.AddWithValue("@ParticipantingEvent", PEvr.Text);
            cmd4.Parameters.AddWithValue("@MobileNumber", int.Parse(PNum.Text));
            cmd4.Parameters.AddWithValue("@Year", int.Parse(EvYear.Text));

            cmd4.ExecuteNonQuery();
            conn.Close();

            MessageBox.Show("Saved succesfully ");
        }

        private void button3_Click_2(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are You Sure, You want to Close??", "Confirmation Message", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
            if (result == System.Windows.Forms.DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void button2_Click_2(object sender, EventArgs e)
        {
           
        }
        public void fillCombobox()
        {
            SqlConnection con = new SqlConnection("Data Source=(local);Initial Catalog=EventList;Integrated Security=True");
            string sql = "select * from EventTable";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader myreader; 

            try
            {
                con.Open();
                myreader = cmd.ExecuteReader(); 
                while (myreader.Read())
                {
                    if (!myreader.IsDBNull(1))
                    {
                        string EventName = myreader.GetString(0);
                        PEvr.Items.Add(EventName);
                    }
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            finally
            {
                con.Close();
            }

        }

        private void PEvr_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click_3(object sender, EventArgs e)
        {
            PName.Clear();
            PNum.Clear();
            

            PName.Focus();
        }

        private void button1_Click_2(object sender, EventArgs e)
        {

        }
        public void save()
        {
            SqlConnection conn = new SqlConnection("Data Source=(local);Initial Catalog=EventList;Integrated Security=True");
            conn.Open();
            SqlCommand cmd4 = new SqlCommand("insert into ParticipantTable values(@ParticipantName, @Class, @ParticipantingEvent, @MobileNumber, @Year, @Description)", conn);

            try
            {
                cmd4.Parameters.AddWithValue("@ParticipantName", PName.Text);
                cmd4.Parameters.AddWithValue("@Class", PClass.Text);
                cmd4.Parameters.AddWithValue("@ParticipantingEvent", PEvr.Text);
                cmd4.Parameters.AddWithValue("@MobileNumber", PNum.Text);
                cmd4.Parameters.AddWithValue("@Year", int.Parse(EvYear.Text));
                cmd4.Parameters.AddWithValue("@Description", Description.Text);


                cmd4.ExecuteNonQuery();


                MessageBox.Show("Added succesfully ");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
            finally
            {
                conn.Close();
            }
        }
        public void clear()
        {
            PName.Clear();
            PNum.Clear();
            Description.Clear();
           
            PName.Focus();
        }
        private void button4_Click_3(object sender, EventArgs e)
        {
            save();
            clear();
        }

        private void button1_Click_3(object sender, EventArgs e)
        {

        }

        private void button2_Click_4(object sender, EventArgs e)
        {
            clear();
        }

        private void button4_Click_2(object sender, EventArgs e)
        {
            string enteredNumber = PNum.Text.Replace(" ", "");

            if (string.IsNullOrWhiteSpace(PName.Text) ||
                string.IsNullOrWhiteSpace(PNum.Text)
                )
            {
                MessageBox.Show("Please Enter valid Details", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else if (EvYear.SelectedItem == null)
            {
                MessageBox.Show("Please Select a valid Year");
            }
            else if (PClass.SelectedItem == null)
            {
                MessageBox.Show("Please Select a valid Class");
            }
            else if (PEvr.SelectedItem == null)
            {
                MessageBox.Show("Please Select a valid Event");
            }
           
            else if (enteredNumber.Length == 10 && int.TryParse(enteredNumber, out _))
            {
                save();
                clear();
            }
            else
            {
                MessageBox.Show("Please Enter a valid 10-digit Mobile number.");
            }
            
        }
        private void ValidateNum() {

           
        }

        private void button2_Click_5(object sender, EventArgs e)
        {
            clear();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Do You want to Close this Window ??", "Confirmation Message", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
            if (result == System.Windows.Forms.DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void button1_Click_4(object sender, EventArgs e)
        {
            clear();
        }
    }
}

