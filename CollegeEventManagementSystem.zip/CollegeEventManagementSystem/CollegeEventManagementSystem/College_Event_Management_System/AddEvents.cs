﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace College_Event_Management_System
{
    public partial class AddEvents : Form
    {
        public AddEvents()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            save();
        }

        private void AddEvents_Load(object sender, EventArgs e)
        {

        }
      
        private void EvYear_TextChanged(object sender, EventArgs e)
        {

        }
        public void save()
        {
            SqlConnection con = new SqlConnection("Data Source=(local);Initial Catalog=EventList;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into EventTable values(@eventname, @Date, @Stcoordinator, @location, @Year, @Description)", con);
            try
            {
                cmd.Parameters.AddWithValue("@eventname", EvName.Text);
                cmd.Parameters.AddWithValue("@Date", datet.Value.Date);
                cmd.Parameters.AddWithValue("@Stcoordinator", Stcoordinator.Text);
                cmd.Parameters.AddWithValue("@location", Location.Text);
                cmd.Parameters.AddWithValue("@Year", EvYear.Text);
                cmd.Parameters.AddWithValue("@Description", Description.Text);

                cmd.ExecuteNonQuery();
                MessageBox.Show("Added succesfully ");
            }
            catch (Exception e)
            {
                MessageBox.Show("Error" +e);
            }
            finally {
                con.Close();
            }
        }

        private void button4_Click_1(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Do You want to Close this Window ??", "Confirmation Message", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
            if (result == System.Windows.Forms.DialogResult.Yes)
            {
                this.Close();
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            clear();
        }

        private void button4_Click_2(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(EvName.Text) ||
              string.IsNullOrWhiteSpace(Stcoordinator.Text) ||
              string.IsNullOrWhiteSpace(Location.Text)
              )
            {
                MessageBox.Show("Please Enter valid Details", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else if (EvYear.SelectedItem == null)
            {
                MessageBox.Show("Please Select a valid Year");
            }
            else
            {
                save();
                clear();
            }
        }
      

        private void button1_Click_1(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Do You want to Close this Window ??", "Confirmation Message", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
            if (result == System.Windows.Forms.DialogResult.Yes)
            {
                this.Close();
            }
        }
        public void clear()
        {
            EvName.Clear();
            Stcoordinator.Clear();
            Location.Clear();
            Description.Clear();
        }
        private void button2_Click_1(object sender, EventArgs e)
        {
            clear();
        }

        private void datet_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            clear();
        }
    }
}
