﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace College_Event_Management_System
{
    public partial class LoginDetail : Form
    {
        public LoginDetail()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }


        private void LoginDetail_Load(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=(local);Initial Catalog=EventList;Integrated Security=True");
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();

            }

            SqlCommand cmd1 = new SqlCommand("SELECT Username, Name, Mail, Status, Post FROM LoginTable", conn);

            SqlDataAdapter da = new SqlDataAdapter();

            DataTable dt = new DataTable();

            da.SelectCommand = cmd1;

            dt.Clear();
            da.Fill(dt);

            LoginTable.DataSource = dt;

            LoginTable.RowHeadersVisible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection("Data Source=(local);Initial Catalog=EventList;Integrated Security=True"))
                {
                    conn.Open();

                    if (LoginTable.SelectedRows.Count > 0)
                    {
                        string UsernameToDelete = LoginTable.SelectedRows[0].Cells["Username"].Value.ToString();

                        using (SqlCommand cmd4 = new SqlCommand("DELETE FROM LoginTable WHERE Username = @Username", conn))
                        {
                            cmd4.Parameters.AddWithValue("@Username", UsernameToDelete);
                            cmd4.ExecuteNonQuery();

                            MessageBox.Show("Successfully Deleted");
                        }
                        
                    }
                    else
                    {
                        MessageBox.Show("Please select a row to delete.");
                    }
                   
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }
        public void loadData()
        {
            SqlConnection conn = new SqlConnection("Data Source=(local);Initial Catalog=EventList;Integrated Security=True");
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();

            }

            SqlCommand cmd1 = new SqlCommand("select  Username, Name, Mail, status,Post from  LoginTable", conn);

            SqlDataAdapter da = new SqlDataAdapter();

            DataTable dt = new DataTable();

            da.SelectCommand = cmd1;

            dt.Clear();
            da.Fill(dt);

            LoginTable.DataSource = dt;
            
        }
        private void button4_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Do You want to Close this Window ??", "Confirmation Message", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
            if (result == System.Windows.Forms.DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void Refresh_Click(object sender, EventArgs e)
        {
            loadData();
        }

        private void LoginTable_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void update_Click(object sender, EventArgs e)
        {
                
            

        }

        private void LoginTable_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void updatebtn_Click(object sender, EventArgs e)
        {
            int Status = (Convert.ToInt32(LoginTable.SelectedRows[0].Cells["Status"].Value) == 0) ? 1 : 0;
            UpdateStatus(Status);
            
        }
     
        private void UpdateStatus(int Status)
        {
            if (LoginTable.SelectedRows.Count > 0)
            {
                int rowIndex = LoginTable.SelectedRows[0].Index;
                
                LoginTable.Rows[rowIndex].Cells["Status"].Value = Status;

                string Username = LoginTable.Rows[rowIndex].Cells["Username"].Value.ToString();
                UpdateDatabaseStatus(Username, Status);
            }
        }

        private void UpdateDatabaseStatus(string Username, int Status)
        {
            using (SqlConnection connection = new SqlConnection("Data Source=(local);Initial Catalog=EventList;Integrated Security=True"))
            {
                try
                {
                    connection.Open();
                    string query = "UPDATE LoginTable SET Status = @Status WHERE Username = @Username";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@Status", Status);
                    command.Parameters.AddWithValue("@Username", Username);
                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error : " + ex.Message);
                }
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection("Data Source=(local);Initial Catalog=EventList;Integrated Security=True"))
                {
                    conn.Open();

                    if (LoginTable.SelectedRows.Count > 0)
                    {
                        string UsernameToDelete = LoginTable.SelectedRows[0].Cells["Username"].Value.ToString();

                        using (SqlCommand cmd4 = new SqlCommand("DELETE FROM LoginTable WHERE Username = @Username", conn))
                        {
                            cmd4.Parameters.AddWithValue("@Username", UsernameToDelete);
                            cmd4.ExecuteNonQuery();

                            MessageBox.Show("Successfully Deleted");
                        }

                    }
                    else
                    {
                        MessageBox.Show("Please select a row to delete.");
                    }
                   
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
            loadData();
        }

        private void txtupdate_TextChanged(object sender, EventArgs e)
        {

        }
    }

}

