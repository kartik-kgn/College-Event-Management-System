﻿namespace College_Event_Management_System
{
    partial class MainFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainFrm));
            this.MainPnl = new System.Windows.Forms.Panel();
            this.ContainerPnl = new System.Windows.Forms.Panel();
            this.logOutbtn = new System.Windows.Forms.Button();
            this.Privacybtn = new System.Windows.Forms.Button();
            this.pListbtn = new System.Windows.Forms.Button();
            this.addPbtn = new System.Windows.Forms.Button();
            this.eventReportbtn = new System.Windows.Forms.Button();
            this.addEventbtn = new System.Windows.Forms.Button();
            this.Logo = new System.Windows.Forms.Label();
            this.MainPnl.SuspendLayout();
            this.ContainerPnl.SuspendLayout();
            this.SuspendLayout();
            // 
            // MainPnl
            // 
            this.MainPnl.BackColor = System.Drawing.Color.Gainsboro;
            this.MainPnl.Controls.Add(this.ContainerPnl);
            this.MainPnl.Controls.Add(this.Logo);
            this.MainPnl.Dock = System.Windows.Forms.DockStyle.Left;
            this.MainPnl.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.MainPnl.Location = new System.Drawing.Point(0, 0);
            this.MainPnl.Name = "MainPnl";
            this.MainPnl.Size = new System.Drawing.Size(231, 1104);
            this.MainPnl.TabIndex = 0;
            this.MainPnl.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // ContainerPnl
            // 
            this.ContainerPnl.Controls.Add(this.logOutbtn);
            this.ContainerPnl.Controls.Add(this.Privacybtn);
            this.ContainerPnl.Controls.Add(this.pListbtn);
            this.ContainerPnl.Controls.Add(this.addPbtn);
            this.ContainerPnl.Controls.Add(this.eventReportbtn);
            this.ContainerPnl.Controls.Add(this.addEventbtn);
            this.ContainerPnl.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.ContainerPnl.Location = new System.Drawing.Point(0, 276);
            this.ContainerPnl.Name = "ContainerPnl";
            this.ContainerPnl.Size = new System.Drawing.Size(231, 828);
            this.ContainerPnl.TabIndex = 8;
            // 
            // logOutbtn
            // 
            this.logOutbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.logOutbtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.logOutbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.logOutbtn.Font = new System.Drawing.Font("Segoe UI Semibold", 8F, System.Drawing.FontStyle.Bold);
            this.logOutbtn.Image = ((System.Drawing.Image)(resources.GetObject("logOutbtn.Image")));
            this.logOutbtn.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.logOutbtn.Location = new System.Drawing.Point(0, 630);
            this.logOutbtn.Name = "logOutbtn";
            this.logOutbtn.Size = new System.Drawing.Size(231, 126);
            this.logOutbtn.TabIndex = 12;
            this.logOutbtn.Text = "LOGOUT";
            this.logOutbtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.logOutbtn.UseVisualStyleBackColor = true;
            this.logOutbtn.Click += new System.EventHandler(this.logOutbtn_Click);
            // 
            // Privacybtn
            // 
            this.Privacybtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Privacybtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.Privacybtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Privacybtn.Font = new System.Drawing.Font("Segoe UI Semibold", 8F, System.Drawing.FontStyle.Bold);
            this.Privacybtn.Image = ((System.Drawing.Image)(resources.GetObject("Privacybtn.Image")));
            this.Privacybtn.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Privacybtn.Location = new System.Drawing.Point(0, 504);
            this.Privacybtn.Name = "Privacybtn";
            this.Privacybtn.Size = new System.Drawing.Size(231, 126);
            this.Privacybtn.TabIndex = 11;
            this.Privacybtn.Text = "PRIVACY";
            this.Privacybtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Privacybtn.UseVisualStyleBackColor = true;
            this.Privacybtn.Click += new System.EventHandler(this.Privacybtn_Click_1);
            // 
            // pListbtn
            // 
            this.pListbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pListbtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.pListbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.pListbtn.Font = new System.Drawing.Font("Segoe UI Semibold", 8F, System.Drawing.FontStyle.Bold);
            this.pListbtn.Image = ((System.Drawing.Image)(resources.GetObject("pListbtn.Image")));
            this.pListbtn.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.pListbtn.Location = new System.Drawing.Point(0, 378);
            this.pListbtn.Name = "pListbtn";
            this.pListbtn.Size = new System.Drawing.Size(231, 126);
            this.pListbtn.TabIndex = 8;
            this.pListbtn.Text = "PARTICIPANT LIST";
            this.pListbtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.pListbtn.UseVisualStyleBackColor = true;
            this.pListbtn.Click += new System.EventHandler(this.pListbtn_Click);
            // 
            // addPbtn
            // 
            this.addPbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.addPbtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.addPbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addPbtn.Font = new System.Drawing.Font("Segoe UI Semibold", 8F, System.Drawing.FontStyle.Bold);
            this.addPbtn.Image = ((System.Drawing.Image)(resources.GetObject("addPbtn.Image")));
            this.addPbtn.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.addPbtn.Location = new System.Drawing.Point(0, 252);
            this.addPbtn.Name = "addPbtn";
            this.addPbtn.Size = new System.Drawing.Size(231, 126);
            this.addPbtn.TabIndex = 10;
            this.addPbtn.Text = "ADD PARTICIPANT";
            this.addPbtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.addPbtn.UseVisualStyleBackColor = true;
            this.addPbtn.Click += new System.EventHandler(this.addPbtn_Click);
            // 
            // eventReportbtn
            // 
            this.eventReportbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.eventReportbtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.eventReportbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.eventReportbtn.Font = new System.Drawing.Font("Segoe UI Semibold", 8F, System.Drawing.FontStyle.Bold);
            this.eventReportbtn.Image = ((System.Drawing.Image)(resources.GetObject("eventReportbtn.Image")));
            this.eventReportbtn.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.eventReportbtn.Location = new System.Drawing.Point(0, 126);
            this.eventReportbtn.Name = "eventReportbtn";
            this.eventReportbtn.Size = new System.Drawing.Size(231, 126);
            this.eventReportbtn.TabIndex = 9;
            this.eventReportbtn.Text = "EVENT REPORT";
            this.eventReportbtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.eventReportbtn.UseVisualStyleBackColor = true;
            this.eventReportbtn.Click += new System.EventHandler(this.eventReportbtn_Click);
            // 
            // addEventbtn
            // 
            this.addEventbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.addEventbtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.addEventbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addEventbtn.Font = new System.Drawing.Font("Segoe UI Semibold", 8F, System.Drawing.FontStyle.Bold);
            this.addEventbtn.Image = ((System.Drawing.Image)(resources.GetObject("addEventbtn.Image")));
            this.addEventbtn.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.addEventbtn.Location = new System.Drawing.Point(0, 0);
            this.addEventbtn.Name = "addEventbtn";
            this.addEventbtn.Size = new System.Drawing.Size(231, 126);
            this.addEventbtn.TabIndex = 7;
            this.addEventbtn.Text = "ADD EVENTS";
            this.addEventbtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.addEventbtn.UseVisualStyleBackColor = true;
            this.addEventbtn.Click += new System.EventHandler(this.addEventbtn_Click);
            // 
            // Logo
            // 
            this.Logo.Image = ((System.Drawing.Image)(resources.GetObject("Logo.Image")));
            this.Logo.Location = new System.Drawing.Point(57, 71);
            this.Logo.Name = "Logo";
            this.Logo.Size = new System.Drawing.Size(127, 120);
            this.Logo.TabIndex = 7;
            // 
            // MainFrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1766, 1104);
            this.Controls.Add(this.MainPnl);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.IsMdiContainer = true;
            this.Name = "MainFrm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MainFrm";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.MainPnl.ResumeLayout(false);
            this.ContainerPnl.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel MainPnl;
        private System.Windows.Forms.Label Logo;
        private System.Windows.Forms.Panel ContainerPnl;
        private System.Windows.Forms.Button logOutbtn;
        public System.Windows.Forms.Button Privacybtn;
        private System.Windows.Forms.Button pListbtn;
        private System.Windows.Forms.Button addPbtn;
        private System.Windows.Forms.Button eventReportbtn;
        private System.Windows.Forms.Button addEventbtn;
    }
}