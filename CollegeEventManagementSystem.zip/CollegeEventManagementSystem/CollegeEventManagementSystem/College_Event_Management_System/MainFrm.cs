﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace College_Event_Management_System
{
    public partial class MainFrm : Form
    {
        public MainFrm()
        {
            InitializeComponent();
        }

        private void CloseBtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void OpenForm(Form newForm)
        {
            if (ActiveMdiChild != null)
            {
                ActiveMdiChild.Close();

                newForm.MdiParent = this;
                newForm.Show();

            }
            else
            {
                newForm.MdiParent = this;
                newForm.Show();
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            OpenForm(new AddEvents());
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenForm(new EventReport());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenForm(new AddParticipant());
        }

        private void button4_Click(object sender, EventArgs e)
        {
            OpenForm(new ParticipantList());
        }

        private void button6_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you want to Logout ??", "Confirmation Message", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
            if (result == System.Windows.Forms.DialogResult.Yes)
            {
                this.Hide();
                LoginFrm lf = new LoginFrm();
                lf.Show();
            }
        }

        private void Privacybtn_Click(object sender, EventArgs e)
        {
            OpenForm(new LoginDetail());
        }

        private void CloseBtn_Click_1(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you want to Exit??", "Confirmation Message", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
            if (result == System.Windows.Forms.DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you want to Exit??", "Confirmation Message", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
            if (result == System.Windows.Forms.DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void addEventbtn_Click(object sender, EventArgs e)
        {
            OpenForm(new AddEvents());
        }

        private void eventReportbtn_Click(object sender, EventArgs e)
        {
            OpenForm(new EventReport());
        }

        private void addPbtn_Click(object sender, EventArgs e)
        {
            OpenForm(new AddParticipant());
        }

        private void pListbtn_Click(object sender, EventArgs e)
        {
            OpenForm(new ParticipantList());
        }

        private void Privacybtn_Click_1(object sender, EventArgs e)
        {
            OpenForm(new LoginDetail());
        }

        private void logOutbtn_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Do You want to Exit??", "Confirmation Message", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
            if (result == System.Windows.Forms.DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}
