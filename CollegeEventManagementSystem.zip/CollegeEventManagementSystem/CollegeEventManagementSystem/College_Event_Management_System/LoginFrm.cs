﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace College_Event_Management_System
{
    public partial class LoginFrm : Form
    {
        public LoginFrm()
        {
            InitializeComponent();
        }

        private void Loginbtn_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection("Data Source=(local);Initial Catalog=EventList;Integrated Security=True"))
            {
                con.Open();

                string query = "SELECT * FROM LoginTable WHERE Username = @Username AND Password = @Password AND status = 1";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    try
                    {
                        cmd.Parameters.AddWithValue("@Username", txtUsername.Text);
                        cmd.Parameters.AddWithValue("@Password", txtPassword.Text);

                        RegistrationForm rf = new RegistrationForm();

                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            if (dr.Read())
                            {
                                int status = Convert.ToInt32(dr["status"]);
                                string post = dr["post"].ToString();

                                if (status == 1)
                                {
                                    if (post == "Admin")
                                    {
                                        MainFrm mf = new MainFrm();
                                        mf.Show();
                                        rf.SaveBtn.Visible = false;
                                        this.Hide();
                                    }
                                    else
                                    {
                                        MainFrm mf = new MainFrm();
                                        mf.Show();
                                        mf.Privacybtn.Visible = false;

                                        rf.SaveBtn2.Visible = false;
                                        this.Hide();
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Your account is currently Inactive.");
                                }
                            }
                            else
                            {
                                lblIncorrect.Visible = true;
                            }
                        }
                    }

                    catch (Exception exce)
                    {
                        MessageBox.Show("Error" + exce);
                    }
                    finally { }
                }
            }
            clear();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            RegistrationForm rf = new RegistrationForm();
            rf.Show();
        }

        private void clrlbl_Click(object sender, EventArgs e)
        {
            clear();
        }
        public void clear()
        {
            txtPassword.Clear();
            txtUsername.Clear();

            txtUsername.Focus();
        }
        private void lblIncorrectUser_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
