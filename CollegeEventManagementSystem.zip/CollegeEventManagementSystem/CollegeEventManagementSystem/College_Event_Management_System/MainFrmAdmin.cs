﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace College_Event_Management_System
{
    public partial class MainFrmAdmin : Form
    {
        public MainFrmAdmin()
        {
            InitializeComponent();
        }
        private void OpenForm(Form newForm)
        {
            if (ActiveMdiChild != null)
            {
                ActiveMdiChild.Close();

                newForm.MdiParent = this;
                newForm.Show();

            }
            else
            {
                newForm.MdiParent = this;
                newForm.Show();
            }
        }

        private void aDDEVENTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenForm(new AddEvents());
        }

        private void rEGISTRATIONToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenForm(new RegistrationForm());
        }

        private void uSERDETAILToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenForm(new LoginDetail());
        }

        private void eVENTREPORTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenForm(new EventReport());
        }

        private void aDDPARTICIPANTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenForm(new AddParticipant());
        }

        private void pARTICIPANTLISTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenForm(new ParticipantList());
        }

        private void eXITToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you want to Logout ??", "Confirmation Message", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
            if (result == System.Windows.Forms.DialogResult.Yes)
            {
                Application.Exit();
            }
        }
        public void invisiblebtn()
        {
            privacybtn.Enabled = false;
            privacybtn.Visible = false;
        }
        private void MainFrmAdmin_Load(object sender, EventArgs e)
        {
            
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void MainFrmAdmin_Click(object sender, EventArgs e)
        {
         
        }

        private void privacybtn_Click(object sender, EventArgs e)
        {

        }

        private void toolStripMenuItem7_Click(object sender, EventArgs e)
        {

        }
    }
}
