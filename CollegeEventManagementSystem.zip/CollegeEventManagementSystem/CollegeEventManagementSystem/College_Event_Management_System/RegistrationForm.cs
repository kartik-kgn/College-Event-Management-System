﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace College_Event_Management_System
{
    public partial class RegistrationForm : Form
    {
        public RegistrationForm()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            userBox.Clear();
            passBox.Clear();
            c.Clear();
            mailBox.Clear();
            
            userBox.Focus();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public void button4_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(userBox.Text) ||
               string.IsNullOrWhiteSpace(passBox.Text) || 
               string.IsNullOrWhiteSpace(mailBox.Text)  ||
               string.IsNullOrWhiteSpace(c.Text)
               )
            {
                MessageBox.Show("Please Enter valid Details", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            SqlConnection con = new SqlConnection("Data Source=(local);Initial Catalog=EventList;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into LoginTable values(@Username, @Password, @Name, @Mail, @Status, @Post)", con);

            cmd.Parameters.AddWithValue("@Username", userBox.Text);
            cmd.Parameters.AddWithValue("@Password", passBox.Text);
            cmd.Parameters.AddWithValue("@Name", c.Text);
            cmd.Parameters.AddWithValue("@Mail", mailBox.Text);
            cmd.Parameters.AddWithValue("@Status", "0");
            cmd.Parameters.AddWithValue("@Post","User");

            cmd.ExecuteNonQuery();
            con.Close();

            MessageBox.Show("Registered succesfully ");
            clear();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            clear();
        }
        public void clear()
        {
            userBox.Clear();
            passBox.Clear();
            c.Clear();
            mailBox.Clear();

            userBox.Focus();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are You Sure, You want to Close??", "Confirmation Message", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
            if (result == System.Windows.Forms.DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
                this.Close();
        }

        private void RegistrationForm_Load(object sender, EventArgs e)
        {

        }

        private void status_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void mailBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void nameBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void passBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void userBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void post_TextChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            clear();
        }

        private void SaveBtn2_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(userBox.Text) ||
               string.IsNullOrWhiteSpace(passBox.Text) ||
               string.IsNullOrWhiteSpace(mailBox.Text) ||
               string.IsNullOrWhiteSpace(c.Text)
               )
            {
                MessageBox.Show("Please Enter valid Details", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            SqlConnection con = new SqlConnection("Data Source=(local);Initial Catalog=EventList;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into LoginTable values(@Username, @Password, @Name, @Mail, @Status, @Post)", con);
            try
            {
                cmd.Parameters.AddWithValue("@Username", userBox.Text);
                cmd.Parameters.AddWithValue("@Password", passBox.Text);
                cmd.Parameters.AddWithValue("@Name", c.Text);
                cmd.Parameters.AddWithValue("@Mail", mailBox.Text);
                cmd.Parameters.AddWithValue("@Status", "0");
                cmd.Parameters.AddWithValue("@Post", "User");

                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Registered succesfully ");
            }
            catch (Exception exc)
            {
                MessageBox.Show("Error" + exc);
            }
            finally
            {
                this.Close();
            }
        }
    }
}
